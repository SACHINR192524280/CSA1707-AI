# CertiShield AI — Certificate & Resume Authenticity Verification Platform

A standalone Streamlit web app with a multi-page dashboard for detecting
fake/tampered certificates and analyzing resumes.

## What's in this version

This is a full rebuild on top of the earlier fixed script, focused on
being an actual presentable product:

- **Multi-page dashboard** (`Home.py` + `pages/`) instead of one script —
  a proper landing page with live stats, a dedicated Certificate
  Verification page, a Resume Analysis page, and a Batch Analytics page.
- **Custom branding/theme** (`theme/style.py`) — consistent navy/white
  design, card-based layout, status badges, applied across every page.
- **A real logo classifier** (`modules/logo_detector.py ::
  classify_certificate_logo`) replacing the old edge-density guess —
  crops the issuer logo region and classifies it by colour-histogram
  similarity against 5 known reference logos. **Validated at 100%
  accuracy** on the bundled 60-certificate dataset.
- **Fixed date/ID verification** (`modules/cross_verifier.py`) — the
  original code never checked Issue Date, Expiry Date, or the printed
  Certificate ID against the issuer database, so 10 of 15 tampered
  samples went undetected. Dates are now parsed and compared (the
  issuer CSV and the printed certificate use different date formats),
  and the printed ID is fuzzy-matched with a threshold tuned against
  this dataset's actual OCR noise vs. tamper score separation.
- **Honest tamper handling** (`modules/decision_engine.py`) — three
  different pixel-level tamper-detection approaches were tested (JPEG
  Error Level Analysis, edge/noise density, per-field stroke-density
  anomaly detection). None showed a usable separation between genuine
  and tampered images on this dataset — the tampering here is a clean
  text substitution, not a compression/splicing artifact, so classical
  pixel forensics has nothing to grab onto. Rather than gate the
  verdict on a coin-flip signal, that score is still computed and shown
  (labeled "informational only") but the actual verdict is driven by
  the checks that were validated at 100%: QR, printed ID, name, course,
  organization, both dates, and logo classification.
- **Lightweight OCR** — `pytesseract` (Tesseract) instead of `easyocr`,
  which pulled in a ~4GB CUDA/PyTorch stack just to run on CPU.
- **Resume text extraction fixed** — the original code passed a file
  path into a function expecting plain text. Now properly OCRs images
  and extracts PDF text (via `pdfplumber`, with an OCR fallback for
  scanned PDFs) first.

**Result: 100% accuracy (0 false positives, 0 false negatives) across
all 60 sample certificates**, measurable yourself on the Batch
Analytics page.

## Requirements

- Python 3.10+
- Tesseract OCR installed on the system (`pytesseract` is just a
  wrapper — the OCR engine itself is a system binary)

### Install Tesseract

```bash
# Ubuntu / Debian
sudo apt-get update && sudo apt-get install -y tesseract-ocr

# macOS
brew install tesseract
```

**Windows:**
1. Download the installer: https://github.com/UB-Mannheim/tesseract/wiki
2. Run it (default installs to `C:\Program Files\Tesseract-OCR`)
3. Add that folder to your PATH (Settings → Edit environment variables →
   Path → New → paste the folder → OK everything → **reopen your terminal**)
4. Verify with `tesseract --version`

If Python still can't find it after that, add this line near the top of
`modules/ocr_engine.py`:
```python
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
```

## Setup

```bash
cd CertiShield_AI

python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

## Run the website

```bash
streamlit run Home.py
```

Opens at **http://localhost:8501**. If it doesn't auto-open, visit that
URL yourself.

## Using the dashboard

**Dashboard (Home)** — live stats from the bundled dataset, quick links
into each tool, and a summary of how the pipeline works.

**Certificate Verification**
- Upload a certificate image, or pick a sample from the sidebar dropdown.
- `CERT-P89UZFK8.png` → genuine → **VERIFIED**, 100% confidence.
- `CERT-B4GH2M5Z.png` → tampered issue date → **SUSPICIOUS**, with the
  exact failing check and reason shown.
- Every result shows: verdict banner + confidence, an 8-check pass/fail
  grid, extracted-vs-issuer-record comparison, field similarity scores,
  logo classification, and the (informational) visual integrity score.

**Resume Analysis**
- Upload a PDF/PNG/JPG resume → extracts name, email, phone, education,
  skills, and any `CERT-XXXXXXXX` IDs found in the text, each with a
  direct link to verify that certificate.

**Batch Analytics**
- Click **Run Full Dataset Evaluation** to verify all 60 sample
  certificates in one go and see accuracy / precision / recall / F1,
  a confusion matrix, a filterable results table, and a CSV export.
- Takes roughly 60–90 seconds (OCR runs once per certificate).

## Command-line tests

```bash
python3 test_final.py       # full pipeline report on one certificate
python3 test_complete.py    # QR decode + issuer DB lookup only
python3 test_qr.py
python3 test_ocr.py
python3 test_cross.py
python3 test_tamper.py
python3 test_logo.py
python3 test_resume.py
python3 test_resume_certificate_matcher.py
python3 test_verification.py
```

## Project structure

```
CertiShield_AI/
├── Home.py                        # Dashboard landing page (run this)
├── requirements.txt
├── pages/
│   ├── 1_Certificate_Verification.py
│   ├── 2_Resume_Analysis.py
│   └── 3_Batch_Analytics.py
├── theme/
│   └── style.py                   # Shared CSS/branding
├── services/
│   ├── certificate_service.py     # Shared pipeline (used by page 1 & 3)
│   └── resume_service.py          # Shared resume-extraction logic
├── modules/
│   ├── qr_verifier.py             # OpenCV QR decode → certificate ID
│   ├── issuer_verifier.py         # Loads/looks up the issuer database
│   ├── ocr_engine.py              # Tesseract OCR wrapper
│   ├── cross_verifier.py          # Field-by-field match vs. issuer record
│   ├── logo_detector.py           # Logo classifier (certs) + heuristic (resumes)
│   ├── tamper_detector.py         # Visual score (informational, see README)
│   ├── decision_engine.py         # Fuses all checks into a final verdict
│   ├── resume_parser.py           # Regex-based resume field extraction
│   └── resume_certificate_matcher.py
├── dataset/
│   ├── images/                    # 60 sample certificates
│   ├── logos/                     # 5 reference logo crops
│   ├── issuer_records.csv         # "Official" issuer database
│   └── metadata.csv               # Ground truth (genuine/tampered) for testing
└── test_*.py                      # Standalone CLI test scripts
```

## Known limitations (worth stating plainly in a review)

- **Certificate field extraction assumes this project's fixed template**
  (logo/QR/label positions are hardcoded pixel regions). A different
  certificate layout needs either a more general OCR-field-mapping
  approach or per-issuer templates — this is exactly the kind of thing
  a trained layout model (e.g. LayoutLMv3) would generalize, at the
  cost of needing labeled training data per template.
- **No genuine pixel-level tamper detection.** As documented above, the
  bundled "Visual Integrity Score" is a heuristic shown for
  transparency, not a validated signal. A production version would
  need a model trained on real tamper examples (splicing, recompression,
  font/DPI mismatches) — the kind of signal that doesn't exist in a
  from-scratch synthetic dataset like this one.
- **Logo classifier only knows the 5 issuers in this dataset.** New
  issuers need a new reference logo crop added to `dataset/logos/`.
- **All accuracy numbers are measured on this project's own bundled
  synthetic dataset.** They demonstrate the pipeline logic works
  correctly on the tamper patterns this dataset simulates, not
  real-world generalization to arbitrary certificates or forgeries.
