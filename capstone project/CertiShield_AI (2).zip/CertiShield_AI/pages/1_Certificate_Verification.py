import streamlit as st
import os
import tempfile

from theme.style import inject_base_css, sidebar_brand, badge, MUTED, GREEN, RED
from services.certificate_service import verify_certificate

st.set_page_config(page_title="Certificate Verification — CertiShield AI", page_icon="🔍", layout="wide")
inject_base_css()
sidebar_brand()

with st.sidebar:
    st.markdown("**Navigate**")
    st.page_link("Home.py", label="Dashboard", icon="🏠")
    st.page_link("pages/1_Certificate_Verification.py", label="Certificate Verification", icon="🔍")
    st.page_link("pages/2_Resume_Analysis.py", label="Resume Analysis", icon="📄")
    st.page_link("pages/3_Batch_Analytics.py", label="Batch Analytics", icon="📊")
    st.markdown("---")
    st.markdown("**Try a sample**")
    DATASET_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "dataset", "images")
    sample_files = sorted(os.listdir(DATASET_DIR)) if os.path.exists(DATASET_DIR) else []
    sample_choice = st.selectbox("Load from bundled dataset", ["— none —"] + sample_files)

st.markdown("## 🔍 Certificate Verification")
st.caption("Upload a certificate image to run the full verification pipeline: QR decode → OCR → logo classification → issuer cross-check.")

col_upload, col_preview = st.columns([1.3, 1])

image_path = None
tmp_to_clean = None

with col_upload:
    uploaded = st.file_uploader("Upload certificate (PNG / JPG)", type=["png", "jpg", "jpeg"])
    if uploaded is not None:
        suffix = os.path.splitext(uploaded.name)[1]
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        tmp.write(uploaded.getbuffer())
        tmp.close()
        image_path = tmp.name
        tmp_to_clean = tmp.name
    elif sample_choice != "— none —":
        image_path = os.path.join(DATASET_DIR, sample_choice)

    run = st.button("Verify Certificate", type="primary", disabled=(image_path is None), use_container_width=True)

with col_preview:
    if image_path:
        st.image(image_path, caption="Uploaded certificate", use_container_width=True)
    else:
        st.info("Upload a certificate, or pick a sample from the sidebar, to preview it here.")

if run and image_path:
    with st.spinner("Running verification pipeline..."):
        result = verify_certificate(image_path)

    final = result["final"]
    cross = result["cross_result"]
    qr = result["qr_result"]
    tamper = result["tamper_result"]
    logo = result["logo_result"]
    record = result["issuer_record"]

    st.write("")

    # ---------------- Verdict banner ----------------
    is_verified = final["final_result"] == "VERIFIED"
    banner_color = GREEN if is_verified else RED
    banner_bg = "#E7F9F1" if is_verified else "#FDECEE"
    icon = "✅" if is_verified else "⚠️"

    st.markdown(
        f"""
        <div style="background:{banner_bg}; border:1.5px solid {banner_color}; border-radius:16px;
                    padding:1.6rem 1.9rem; display:flex; justify-content:space-between; align-items:center;">
            <div>
                <div style="font-size:1.6rem; font-weight:800; color:{banner_color};">{icon} {final['final_result']}</div>
                <div style="color:{MUTED}; margin-top:4px;">
                    {final['checks_passed']} / {final['checks_total']} verification checks passed
                </div>
            </div>
            <div style="text-align:right;">
                <div style="font-size:2.2rem; font-weight:800; color:{banner_color};">{final['confidence']}%</div>
                <div style="color:{MUTED}; font-size:0.82rem;">confidence score</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if final["reasons"]:
        with st.container():
            st.markdown("**Flagged reasons:**")
            for r in final["reasons"]:
                st.markdown(f"- {r}")

    st.write("")

    # ---------------- Per-check breakdown ----------------
    st.markdown("#### Verification Checklist")

    checks = [
        ("QR Code", final["qr_status"]),
        ("Certificate ID", final["id_status"]),
        ("Candidate Name", final["name_status"]),
        ("Course Name", final["course_status"]),
        ("Issuing Organization", final["issuer_status"]),
        ("Issue Date", final["issue_date_status"]),
        ("Expiry Date", final["expiry_date_status"]),
        ("Logo Match", final["logo_status"]),
    ]

    grid = st.columns(4)
    for i, (label, status) in enumerate(checks):
        kind = "green" if status == "PASS" else "red"
        icon = "✓" if status == "PASS" else "✕"
        with grid[i % 4]:
            st.markdown(
                f"""
                <div class="cs-card" style="text-align:center; padding:0.9rem;">
                    <div style="font-size:1.3rem; color:{GREEN if status=='PASS' else RED};">{icon}</div>
                    <div style="font-weight:600; font-size:0.88rem; margin-top:2px;">{label}</div>
                    {badge(status, kind)}
                </div>
                """,
                unsafe_allow_html=True,
            )

    st.write("")

    # ---------------- Extracted vs Issuer record ----------------
    left, right = st.columns(2)

    with left:
        st.markdown("#### Extracted from Document")
        st.markdown(
            f"""
            <div class="cs-card">
            <b>Certificate ID</b><br>{cross.get('printed_certificate_id') or '—'}<br><br>
            <b>Issue Date (as printed)</b><br>{cross.get('printed_issue_date') or '—'}<br><br>
            <b>Expiry Date (as printed)</b><br>{cross.get('printed_expiry_date') or '—'}<br><br>
            <b>QR Decoded URL</b><br><span style="font-size:0.85rem;color:{MUTED};">{qr.get('data') or '—'}</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with right:
        st.markdown("#### Matched Issuer Record")
        if record:
            st.markdown(
                f"""
                <div class="cs-card">
                <b>Candidate Name</b><br>{record.get('candidate_name')}<br><br>
                <b>Course</b><br>{record.get('course_name')}<br><br>
                <b>Issuing Organization</b><br>{record.get('issuing_organization')}<br><br>
                <b>Issue → Expiry</b><br>{record.get('issue_date')} → {record.get('expiry_date')}
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f'<div class="cs-card">No matching record found in the issuer database for this Certificate ID.</div>',
                unsafe_allow_html=True,
            )

    st.write("")

    # ---------------- Similarity scores ----------------
    st.markdown("#### Field Similarity Scores")
    sim_cols = st.columns(4)
    sims = [
        ("Name", cross.get("name_score", 0)),
        ("Course", cross.get("course_score", 0)),
        ("Organization", cross.get("organization_score", 0)),
        ("Certificate ID", cross.get("id_score", 0)),
    ]
    for col, (label, score) in zip(sim_cols, sims):
        with col:
            color = GREEN if score >= 90 else ("#F5A524" if score >= 70 else RED)
            st.markdown(f"**{label}**")
            st.progress(min(int(score), 100))
            st.markdown(f"<span style='color:{color};font-weight:700;'>{score:.1f}%</span>", unsafe_allow_html=True)

    st.write("")

    # ---------------- Logo + visual info ----------------
    logo_col, visual_col = st.columns(2)
    with logo_col:
        st.markdown("#### Logo Classification")
        st.markdown(
            f"""
            <div class="cs-card">
            Detected issuer logo: <b>{logo.get('detected_org') or 'Not confidently classified'}</b><br>
            Match confidence: <b>{logo.get('confidence', 0)}%</b>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with visual_col:
        st.markdown("#### Visual Integrity Score")
        st.markdown(
            f"""
            <div class="cs-card">
            Score: <b>{final.get('visual_score', 0)}</b> &nbsp; ({final.get('tamper_status')})<br>
            <span style="color:{MUTED}; font-size:0.82rem;">
            Informational only — a generic edge/noise heuristic. On this dataset, the actual
            verdict is driven by the field cross-checks above, which were validated at 100%
            accuracy; pixel-level tamper cues did not show a reliable signal on clean synthetic
            renders (see README for the full analysis).
            </span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with st.expander("Raw OCR text (debug)"):
        st.text(result["ocr_text"])

if tmp_to_clean and os.path.exists(tmp_to_clean) and not run:
    pass  # keep temp file around for the preview during this run
