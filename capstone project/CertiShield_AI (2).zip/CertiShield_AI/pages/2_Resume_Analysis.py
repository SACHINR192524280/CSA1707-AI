import streamlit as st
import os
import tempfile

from theme.style import inject_base_css, sidebar_brand, MUTED, GREEN, RED
from services.resume_service import analyze_resume

st.set_page_config(page_title="Resume Analysis — CertiShield AI", page_icon="📄", layout="wide")
inject_base_css()
sidebar_brand()

with st.sidebar:
    st.markdown("**Navigate**")
    st.page_link("Home.py", label="Dashboard", icon="🏠")
    st.page_link("pages/1_Certificate_Verification.py", label="Certificate Verification", icon="🔍")
    st.page_link("pages/2_Resume_Analysis.py", label="Resume Analysis", icon="📄")
    st.page_link("pages/3_Batch_Analytics.py", label="Batch Analytics", icon="📊")
    st.markdown("---")
    st.caption(
        "Extracts candidate details and any referenced certificate IDs. "
        "Take a detected ID to the Certificate Verification page to confirm it."
    )

st.markdown("## 📄 Resume Analysis")
st.caption("Upload a resume (PDF, PNG, or JPG) to extract candidate information and detect referenced certificates.")

uploaded = st.file_uploader("Upload resume", type=["pdf", "png", "jpg", "jpeg"])

if uploaded is not None:
    suffix = os.path.splitext(uploaded.name)[1]
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded.getbuffer())
    tmp.close()

    run = st.button("Analyze Resume", type="primary")

    if run:
        with st.spinner("Extracting resume content..."):
            result = analyze_resume(tmp.name, suffix)

        if not result["success"]:
            st.error("Could not extract any readable text from this file. Try a clearer scan or a text-based PDF.")
        else:
            parsed = result["parsed"]
            logo = result["logo"]

            st.write("")
            st.markdown("#### Candidate Information")
            c1, c2, c3, c4 = st.columns(4)
            for col, label, value in zip(
                [c1, c2, c3, c4],
                ["Name", "Email", "Phone", "Header Graphic"],
                [
                    parsed.get("name") or "Not detected",
                    parsed.get("email") or "Not detected",
                    parsed.get("phone") or "Not detected",
                    "Detected" if logo.get("detected") else "Not detected",
                ],
            ):
                with col:
                    st.markdown(
                        f"""
                        <div class="cs-card" style="text-align:center;">
                            <div style="font-weight:700; font-size:0.95rem;">{value}</div>
                            <div style="color:{MUTED}; font-size:0.78rem; text-transform:uppercase; letter-spacing:0.03em;">{label}</div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

            st.write("")
            edu_col, skill_col = st.columns(2)

            with edu_col:
                st.markdown("#### Education")
                education = parsed.get("education", [])
                if education:
                    st.markdown(
                        '<div class="cs-card">' + "".join(f"• {e}<br>" for e in education) + "</div>",
                        unsafe_allow_html=True,
                    )
                else:
                    st.info("No education entries detected.")

            with skill_col:
                st.markdown("#### Skills")
                skills = parsed.get("skills", [])
                if skills:
                    chips = " ".join(
                        f'<span class="cs-badge cs-badge-gray" style="margin:3px;">{s}</span>' for s in skills
                    )
                    st.markdown(f'<div class="cs-card">{chips}</div>', unsafe_allow_html=True)
                else:
                    st.info("No skills detected.")

            st.write("")
            st.markdown("#### Certificate IDs Found")
            certs = parsed.get("certificates", [])
            if certs:
                for cert in certs:
                    cc1, cc2 = st.columns([3, 1])
                    with cc1:
                        st.markdown(
                            f'<div class="cs-card" style="padding:0.7rem 1rem;">🔗 <b>{cert}</b></div>',
                            unsafe_allow_html=True,
                        )
                    with cc2:
                        st.page_link(
                            "pages/1_Certificate_Verification.py",
                            label="Verify this ID →",
                            icon="🔍",
                        )
                st.caption(
                    "Certificate IDs referenced on the resume — open Certificate Verification "
                    "and upload the matching certificate image to confirm authenticity."
                )
            else:
                st.info("No certificate IDs (format CERT-XXXXXXXX) found in this resume.")

            with st.expander("Raw extracted text (debug)"):
                st.text(result["text"])
else:
    st.info("Upload a resume file to get started.")
