import streamlit as st
import pandas as pd
import os
import plotly.graph_objects as go
import plotly.express as px

from theme.style import inject_base_css, sidebar_brand, stat_card, GREEN, RED, NAVY, MUTED
from services.certificate_service import verify_certificate

st.set_page_config(page_title="Batch Analytics — CertiShield AI", page_icon="📊", layout="wide")
inject_base_css()
sidebar_brand()

with st.sidebar:
    st.markdown("**Navigate**")
    st.page_link("Home.py", label="Dashboard", icon="🏠")
    st.page_link("pages/1_Certificate_Verification.py", label="Certificate Verification", icon="🔍")
    st.page_link("pages/2_Resume_Analysis.py", label="Resume Analysis", icon="📄")
    st.page_link("pages/3_Batch_Analytics.py", label="Batch Analytics", icon="📊")
    st.markdown("---")
    st.caption("Runs the full pipeline across every certificate in the bundled sample dataset and scores it against ground truth.")

st.markdown("## 📊 Batch Analytics")
st.caption("Run the verification pipeline across the entire sample dataset (45 genuine + 15 tampered) and measure real accuracy.")

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
IMAGES_DIR = os.path.join(BASE_DIR, "dataset", "images")
META_PATH = os.path.join(BASE_DIR, "dataset", "metadata.csv")

if not os.path.exists(META_PATH):
    st.error("Bundled dataset not found (dataset/metadata.csv missing).")
    st.stop()

meta = pd.read_csv(META_PATH)

run = st.button("▶ Run Full Dataset Evaluation", type="primary")

if "batch_results" not in st.session_state:
    st.session_state["batch_results"] = None

if run:
    progress = st.progress(0, text="Starting...")
    rows = []
    n = len(meta)
    for i, r in meta.iterrows():
        path = os.path.join(IMAGES_DIR, r["image_file"])
        result = verify_certificate(path)
        final = result["final"]
        predicted_tampered = final["final_result"] != "VERIFIED"
        rows.append({
            "certificate_id": r["certificate_id"],
            "actual_tampered": bool(r["is_tampered"]),
            "tampered_field": r["tampered_field"],
            "predicted_tampered": predicted_tampered,
            "predicted_result": final["final_result"],
            "confidence": final["confidence"],
            "checks_passed": final["checks_passed"],
            "checks_total": final["checks_total"],
        })
        progress.progress((i + 1) / n, text=f"Verifying {r['certificate_id']} ({i+1}/{n})")
    progress.empty()
    st.session_state["batch_results"] = pd.DataFrame(rows)

results = st.session_state["batch_results"]

if results is None:
    st.info("Click **Run Full Dataset Evaluation** to verify all 60 sample certificates and see measured accuracy.")
else:
    tp = int(((results.predicted_tampered) & (results.actual_tampered)).sum())
    tn = int(((~results.predicted_tampered) & (~results.actual_tampered)).sum())
    fp = int(((results.predicted_tampered) & (~results.actual_tampered)).sum())
    fn = int(((~results.predicted_tampered) & (results.actual_tampered)).sum())
    total = len(results)
    accuracy = round((tp + tn) / total * 100, 1) if total else 0
    precision = round(tp / (tp + fp) * 100, 1) if (tp + fp) else 0
    recall = round(tp / (tp + fn) * 100, 1) if (tp + fn) else 0
    f1 = round(2 * precision * recall / (precision + recall), 1) if (precision + recall) else 0

    c1, c2, c3, c4 = st.columns(4)
    stat_card("Accuracy", f"{accuracy}%", f"{tp+tn}/{total} correct", c1)
    stat_card("Precision", f"{precision}%", "of flagged, truly tampered", c2)
    stat_card("Recall", f"{recall}%", "of tampered, correctly caught", c3)
    stat_card("F1 Score", f"{f1}%", "precision/recall balance", c4)

    st.write("")
    chart_col, matrix_col = st.columns([1.4, 1])

    with chart_col:
        st.markdown("#### Verdict Distribution")
        vc = results["predicted_result"].value_counts().reset_index()
        vc.columns = ["Verdict", "Count"]
        fig = px.bar(
            vc, x="Verdict", y="Count", color="Verdict",
            color_discrete_map={"VERIFIED": GREEN, "SUSPICIOUS": RED},
            text="Count",
        )
        fig.update_layout(
            showlegend=False, height=320, plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(l=10, r=10, t=10, b=10),
        )
        st.plotly_chart(fig, use_container_width=True)

    with matrix_col:
        st.markdown("#### Confusion Matrix")
        z = [[tn, fp], [fn, tp]]
        fig2 = go.Figure(data=go.Heatmap(
            z=z,
            x=["Predicted Genuine", "Predicted Tampered"],
            y=["Actual Genuine", "Actual Tampered"],
            colorscale=[[0, "#EEF1F8"], [1, NAVY]],
            text=z, texttemplate="%{text}", textfont={"size": 18},
            showscale=False,
        ))
        fig2.update_layout(height=320, margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig2, use_container_width=True)

    st.write("")
    st.markdown("#### Per-Certificate Results")

    filt = st.radio("Filter", ["All", "Correct only", "Incorrect only"], horizontal=True)
    display_df = results.copy()
    display_df["correct"] = display_df["predicted_tampered"] == display_df["actual_tampered"]
    if filt == "Correct only":
        display_df = display_df[display_df["correct"]]
    elif filt == "Incorrect only":
        display_df = display_df[~display_df["correct"]]

    display_df = display_df.rename(columns={
        "certificate_id": "Certificate ID",
        "actual_tampered": "Actually Tampered",
        "tampered_field": "Tampered Field",
        "predicted_result": "Predicted",
        "confidence": "Confidence %",
        "checks_passed": "Checks Passed",
    })
    st.dataframe(
        display_df[["Certificate ID", "Actually Tampered", "Tampered Field", "Predicted", "Confidence %", "Checks Passed"]],
        use_container_width=True,
        hide_index=True,
    )

    csv = results.to_csv(index=False).encode("utf-8")
    st.download_button("⬇ Download full results (CSV)", csv, "batch_verification_results.csv", "text/csv")
