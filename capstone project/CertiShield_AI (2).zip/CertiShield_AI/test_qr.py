import os
from modules.qr_verifier import verify_qr


image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")


result = verify_qr(image_path)


print("==============================")
print("       QR VERIFICATION")
print("==============================")

print("QR Found       :", result["qr_found"])
print("QR Data        :", result["data"])
print("Certificate ID :", result["certificate_id"])
print("Message        :", result["message"])

print("==============================")