import os
from modules.ocr_engine import extract_text as extract_image_text
from modules.resume_parser import parse_resume
from modules.logo_detector import detect_logo


def extract_resume_text(path: str, suffix: str) -> str:
    """
    parse_resume() expects plain text, not a file path, so the resume
    (PDF or image) needs its text pulled out first: pdfplumber for
    text-based PDFs, OCR for images (and as a fallback for
    scanned/image-only PDFs with no extractable text layer).
    """
    if suffix.lower() == ".pdf":
        import pdfplumber

        text = ""
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                text += (page.extract_text() or "") + "\n"

        if text.strip():
            return text

        try:
            with pdfplumber.open(path) as pdf:
                first_page = pdf.pages[0]
                image = first_page.to_image(resolution=200).original
                tmp_png = path + "_page1.png"
                image.save(tmp_png)
                ocr_result = extract_image_text(tmp_png)
                os.remove(tmp_png)
                return ocr_result.get("text", "")
        except Exception:
            return ""

    ocr_result = extract_image_text(path)
    return ocr_result.get("text", "")


def analyze_resume(path: str, suffix: str) -> dict:
    text = extract_resume_text(path, suffix)
    if not text.strip():
        return {"success": False, "text": "", "parsed": None, "logo": None}

    parsed = parse_resume(text)
    logo = detect_logo(path) if suffix.lower() != ".pdf" else {"detected": False, "message": "Logo check applies to image uploads"}

    return {"success": True, "text": text, "parsed": parsed, "logo": logo}
