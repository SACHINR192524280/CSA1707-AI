"""
Runs the full certificate-verification pipeline for one image and
returns a single structured result. Shared by the Certificate
Verification page (one file at a time) and the Batch Analytics page
(all 60 dataset files), so both always use exactly the same logic.
"""

from modules.qr_verifier import verify_qr
from modules.issuer_verifier import load_issuer_database
from modules.ocr_engine import extract_text
from modules.cross_verifier import compare_certificate
from modules.tamper_detector import detect_tampering
from modules.logo_detector import classify_certificate_logo
from modules.decision_engine import make_final_decision

_ISSUER_DB = None


def _db():
    global _ISSUER_DB
    if _ISSUER_DB is None:
        _ISSUER_DB = load_issuer_database()
    return _ISSUER_DB


def verify_certificate(image_path: str) -> dict:
    data = _db()

    qr_result = verify_qr(image_path)
    cert_id = qr_result.get("certificate_id")

    match = data[data["certificate_id"].astype(str).str.strip() == str(cert_id).strip()]

    ocr_result = extract_text(image_path)
    tamper_result = detect_tampering(image_path)
    logo_result = classify_certificate_logo(image_path)

    if match.empty:
        cross_result = {
            "name_score": 0, "course_score": 0, "organization_score": 0,
            "name_match": False, "course_match": False, "organization_match": False,
            "id_score": 0, "id_match": False, "printed_certificate_id": None,
            "issue_date_match": False, "printed_issue_date": None,
            "expiry_date_match": False, "printed_expiry_date": None,
            "expected_organization": None, "expected_name": None,
            "expected_course": None, "expected_issue_date": None, "expected_expiry_date": None,
        }
        final = make_final_decision(qr_result, cross_result, tamper_result, logo_result)
        return {
            "image_path": image_path,
            "qr_result": qr_result,
            "cross_result": cross_result,
            "tamper_result": tamper_result,
            "logo_result": logo_result,
            "final": final,
            "issuer_record": None,
            "ocr_text": ocr_result.get("text", ""),
        }

    record = match.iloc[0]
    cross_result = compare_certificate(ocr_result["text"], record)
    final = make_final_decision(qr_result, cross_result, tamper_result, logo_result)

    return {
        "image_path": image_path,
        "qr_result": qr_result,
        "cross_result": cross_result,
        "tamper_result": tamper_result,
        "logo_result": logo_result,
        "final": final,
        "issuer_record": record.to_dict(),
        "ocr_text": ocr_result.get("text", ""),
    }
