"""
Fuses every module's output into one final verdict.

Design note (read this before changing thresholds):
Three independent signals were evaluated for pixel-level tamper
detection on this dataset - JPEG Error Level Analysis, generic
edge/noise density, and per-field stroke-density anomaly detection.
None showed a usable separation between genuine and tampered images
(full analysis + numbers in README.md / TECHNICAL_NOTES.md) - the
tamper simulation here is a clean text-value substitution, not a
compression or splicing artifact, so classical pixel forensics has
nothing to grab onto. Rather than gate the verdict on a coin-flip
signal, the "visual_score" is still computed and shown (useful
diagnostic context, and a hook for a properly trained tamper model
later) but does NOT affect final_result. The verdict is instead driven
by the checks that were actually validated at 100% accuracy on the
full 60-certificate dataset: QR, printed Certificate ID, Candidate
Name, Course, Issuing Organization, Issue Date, Expiry Date (all
cross-checked against the issuer database) and Logo classification.
"""

HARD_GATE_KEYS = (
    "qr_status",
    "id_status",
    "name_status",
    "course_status",
    "issuer_status",
    "issue_date_status",
    "expiry_date_status",
    "logo_status",
)


def make_final_decision(qr_result, cross_result, tamper_result, logo_result=None):

    reasons = []

    if qr_result.get("qr_found", False):
        qr_status = "PASS"
    else:
        qr_status = "FAIL"
        reasons.append("QR code could not be detected or decoded")

    if cross_result.get("id_match", False):
        id_status = "PASS"
    else:
        id_status = "FAIL"
        reasons.append("Printed Certificate ID does not match the issuer database")

    if cross_result.get("name_match", False):
        name_status = "PASS"
    else:
        name_status = "FAIL"
        reasons.append("Candidate name does not match issuer database")

    if cross_result.get("course_match", False):
        course_status = "PASS"
    else:
        course_status = "FAIL"
        reasons.append("Course does not match issuer database")

    if cross_result.get("organization_match", False):
        issuer_status = "PASS"
    else:
        issuer_status = "FAIL"
        reasons.append("Issuing organization does not match")

    if cross_result.get("issue_date_match", False):
        issue_date_status = "PASS"
    else:
        issue_date_status = "FAIL"
        reasons.append("Issue date does not match issuer database")

    if cross_result.get("expiry_date_match", False):
        expiry_date_status = "PASS"
    else:
        expiry_date_status = "FAIL"
        reasons.append("Expiry date does not match issuer database")

    logo_result = logo_result or {}
    expected_org = cross_result.get("expected_organization")
    detected_org = logo_result.get("detected_org")
    if detected_org is not None and expected_org is not None and detected_org == expected_org:
        logo_status = "PASS"
    elif detected_org is None:
        logo_status = "PASS"  # couldn't extract a logo region - don't penalize for that alone
    else:
        logo_status = "FAIL"
        reasons.append(f"Logo appears to belong to '{detected_org}', not the claimed issuer")

    # Informational only - does not gate the final verdict (see module docstring).
    tamper_status = "REVIEW" if tamper_result.get("tampered", False) else "OK"

    statuses = {
        "qr_status": qr_status,
        "id_status": id_status,
        "name_status": name_status,
        "course_status": course_status,
        "issuer_status": issuer_status,
        "issue_date_status": issue_date_status,
        "expiry_date_status": expiry_date_status,
        "logo_status": logo_status,
    }

    passed = sum(1 for k in HARD_GATE_KEYS if statuses[k] == "PASS")
    confidence = round(100 * passed / len(HARD_GATE_KEYS), 1)

    final_result = "VERIFIED" if passed == len(HARD_GATE_KEYS) else "SUSPICIOUS"

    return {
        **statuses,
        "tamper_status": tamper_status,
        "visual_score": tamper_result.get("score", 0),
        "final_result": final_result,
        "confidence": confidence,
        "checks_passed": passed,
        "checks_total": len(HARD_GATE_KEYS),
        "reasons": reasons,
    }
