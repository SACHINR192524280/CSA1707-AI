import cv2
import numpy as np


def detect_tampering(image_path):

    image = cv2.imread(image_path)

    if image is None:
        return {
            "tampered": False,
            "score": 0,
            "message": "Could not open image"
        }

    # Convert image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Detect edges
    edges = cv2.Canny(gray, 100, 200)

    # Calculate edge density
    edge_pixels = np.sum(edges > 0)
    total_pixels = edges.shape[0] * edges.shape[1]

    edge_density = edge_pixels / total_pixels

    # Calculate image noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    noise = cv2.absdiff(gray, blurred)

    noise_score = np.mean(noise)

    # Combine scores
    tamper_score = (edge_density * 100) + noise_score

    # Basic threshold
    if tamper_score > 15:
        tampered = True
        message = "Possible image modification detected"
    else:
        tampered = False
        message = "No obvious image modification detected"

    return {
        "tampered": tampered,
        "score": round(float(tamper_score), 2),
        "message": message
    }