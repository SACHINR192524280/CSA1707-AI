import os
import platform
import cv2
import pytesseract


def _auto_configure_tesseract():
    """
    On Windows, pytesseract needs to know exactly where tesseract.exe
    lives unless it's on PATH. Rather than requiring every user to edit
    their PATH, check the common install locations directly.
    """
    if platform.system() != "Windows":
        return

    candidates = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
        os.path.expandvars(r"%USERPROFILE%\AppData\Local\Tesseract-OCR\tesseract.exe"),
    ]

    for path in candidates:
        if path and os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            return


_auto_configure_tesseract()


def extract_text(image_path):
    """
    Extracts all text from a certificate/resume image using Tesseract OCR.
    """

    image = cv2.imread(image_path)

    if image is None:
        return {
            "success": False,
            "text": "",
            "message": "Could not open image"
        }

    # Enlarge image for better OCR
    image = cv2.resize(
        image,
        None,
        fx=2,
        fy=2,
        interpolation=cv2.INTER_CUBIC
    )

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    try:
        text = pytesseract.image_to_string(gray)
    except pytesseract.TesseractNotFoundError:
        return {
            "success": False,
            "text": "",
            "message": (
                "Tesseract OCR is not installed or not found. Install it from "
                "https://github.com/UB-Mannheim/tesseract/wiki, or if it's already "
                "installed somewhere non-standard, set the path manually at the top "
                "of modules/ocr_engine.py: "
                "pytesseract.pytesseract.tesseract_cmd = r'C:\\path\\to\\tesseract.exe'"
            )
        }

    if text.strip():
        return {
            "success": True,
            "text": text,
            "message": "Text extracted successfully"
        }

    return {
        "success": False,
        "text": "",
        "message": "No text detected"
    }
