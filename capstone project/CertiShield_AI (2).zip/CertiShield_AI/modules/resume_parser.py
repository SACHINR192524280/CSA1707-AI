import re


def parse_resume(text):

    result = {
        "name": None,
        "email": None,
        "phone": None,
        "education": [],
        "skills": [],
        "certificates": []
    }

    # -----------------------------
    # EMAIL
    # -----------------------------
    email = re.search(
        r'[\w\.-]+@[\w\.-]+\.\w+',
        text
    )

    if email:
        result["email"] = email.group(0)


    # -----------------------------
    # PHONE
    # -----------------------------
    phone = re.search(
        r'(\+91[\s-]?)?[6-9]\d{9}',
        text
    )

    if phone:
        result["phone"] = phone.group(0)


    # -----------------------------
    # EDUCATION
    # -----------------------------
    education_keywords = [
        "B.E",
        "BE",
        "B.Tech",
        "BTECH",
        "M.E",
        "ME",
        "M.Tech",
        "MTECH",
        "B.Sc",
        "BSC",
        "M.Sc",
        "MSC",
        "MBA",
        "BCA",
        "MCA",
        "Computer Science",
        "Cyber Security"
    ]

    for keyword in education_keywords:

        if keyword.lower() in text.lower():

            result["education"].append(keyword)


    # -----------------------------
    # SKILLS
    # -----------------------------
    skill_list = [
        "Python",
        "Java",
        "C",
        "C++",
        "JavaScript",
        "HTML",
        "CSS",
        "SQL",
        "Linux",
        "Cyber Security",
        "Machine Learning",
        "Deep Learning",
        "Artificial Intelligence",
        "Cloud Computing",
        "AWS",
        "Azure",
        "Git",
        "GitHub",
        "Docker",
        "Kali Linux",
        "Networking"
    ]

    for skill in skill_list:

        if skill.lower() in text.lower():

            result["skills"].append(skill)


    # -----------------------------
    # CERTIFICATE IDs
    # -----------------------------
    certificate_ids = re.findall(
        r'CERT-[A-Z0-9]+',
        text
    )

    result["certificates"] = list(
        dict.fromkeys(certificate_ids)
    )


    # -----------------------------
    # NAME
    # -----------------------------
    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    if lines:

        # First meaningful line is used
        # as a basic name estimate.
        result["name"] = lines[0]


    return result