import cv2
import re


def verify_qr(image_path):

    image = cv2.imread(image_path)

    if image is None:
        return {
            "qr_found": False,
            "certificate_id": None,
            "data": None,
            "message": "Could not open image"
        }

    detector = cv2.QRCodeDetector()

    # Try original image
    data, points, _ = detector.detectAndDecode(image)

    if data:
        return make_result(data)

    # Try enlarged image
    enlarged = cv2.resize(
        image,
        None,
        fx=2,
        fy=2,
        interpolation=cv2.INTER_CUBIC
    )

    data, points, _ = detector.detectAndDecode(enlarged)

    if data:
        return make_result(data)

    # Try grayscale image
    gray = cv2.cvtColor(enlarged, cv2.COLOR_BGR2GRAY)

    data, points, _ = detector.detectAndDecode(gray)

    if data:
        return make_result(data)

    # Try adaptive threshold
    threshold = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        11,
        2
    )

    data, points, _ = detector.detectAndDecode(threshold)

    if data:
        return make_result(data)

    return {
        "qr_found": False,
        "certificate_id": None,
        "data": None,
        "message": "QR code detected visually but could not be decoded"
    }


def make_result(data):

    match = re.search(r"CERT-[A-Z0-9]+", data)

    certificate_id = match.group(0) if match else None

    return {
        "qr_found": True,
        "certificate_id": certificate_id,
        "data": data,
        "message": "QR code detected successfully"
    }