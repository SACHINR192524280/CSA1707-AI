from difflib import SequenceMatcher


def similarity(text1, text2):

    if not text1 or not text2:
        return 0.0

    text1 = str(text1).strip().lower()
    text2 = str(text2).strip().lower()

    return round(
        SequenceMatcher(None, text1, text2).ratio() * 100,
        2
    )


def match_resume_certificate(parsed_resume, database_record):

    resume_name = parsed_resume.get("name")

    resume_certificates = parsed_resume.get(
        "certificates", []
    )

    database_name = database_record.get(
        "candidate_name",
        database_record.get("name", "")
    )

    database_certificate_id = str(
        database_record.get("certificate_id", "")
    ).strip()


    # --------------------------------
    # Certificate ID Match
    # --------------------------------

    certificate_match = (
        database_certificate_id in resume_certificates
    )


    # --------------------------------
    # Name Match
    # --------------------------------

    name_score = similarity(
        resume_name,
        database_name
    )

    name_match = name_score >= 80


    # --------------------------------
    # Final Match
    # --------------------------------

    if certificate_match and name_match:

        final_result = "MATCH"

    elif certificate_match and not name_match:

        final_result = "SUSPICIOUS"

    else:

        final_result = "NO MATCH"


    return {
        "certificate_match": certificate_match,
        "name_match": name_match,
        "name_score": name_score,
        "resume_name": resume_name,
        "database_name": database_name,
        "certificate_id": database_certificate_id,
        "final_result": final_result
    }