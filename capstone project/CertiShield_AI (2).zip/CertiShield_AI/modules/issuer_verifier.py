import pandas as pd
from rapidfuzz import fuzz


def load_issuer_database():
    return pd.read_csv(
        "dataset/issuer_records.csv",
        sep="\t"
    )


def verify_certificate(certificate_id, name, course):
    data = load_issuer_database()

    for _, row in data.iterrows():

        id_match = (
            str(row["certificate_id"]).strip()
            == str(certificate_id).strip()
        )

        name_score = fuzz.ratio(
            str(name).lower(),
            str(row["candidate_name"]).lower()
        )

        course_score = fuzz.ratio(
            str(course).lower(),
            str(row["course_name"]).lower()
        )

        if id_match and name_score >= 80 and course_score >= 80:

            return {
                "verified": True,
                "certificate_id": certificate_id,
                "name_score": name_score,
                "course_score": course_score,
                "message": "Certificate verified successfully"
            }

    return {
        "verified": False,
        "certificate_id": certificate_id,
        "name_score": 0,
        "course_score": 0,
        "message": "Certificate could not be verified"
    }