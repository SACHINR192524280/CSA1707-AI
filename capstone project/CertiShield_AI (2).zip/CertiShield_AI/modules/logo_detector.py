"""
Logo detection.

Two different jobs live here:

1. classify_certificate_logo() - for certificates rendered from this
   project's known template. The issuer logo always sits in the same
   region, so it's cropped and classified by colour-histogram
   similarity against one reference crop per known issuing
   organization (dataset/logos/*.png, 5 classes). This gives a real,
   independent "does the logo actually belong to the org this
   certificate claims to be from" signal, used by the decision
   engine.

2. detect_logo() - for arbitrary resumes, which don't come from a
   known template and aren't necessarily from one of the 5 known
   issuers. This stays a generic edge-density heuristic ("is there
   probably some graphic/logo in the header") since there's no fixed
   region or known reference set to match against.
"""

import os
import cv2

LOGO_BBOX = (60, 55, 130, 125)  # fixed region on the certificate template

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
LOGO_REF_DIR = os.path.join(_THIS_DIR, "..", "dataset", "logos")

ORG_NAMES = {
    "vertex_professional_training": "Vertex Professional Training",
    "summit_online_university": "Summit Online University",
    "nextech_skill_academy": "NexTech Skill Academy",
    "global_learners_institute": "Global Learners Institute",
    "brightpath_certification_board": "BrightPath Certification Board",
}


def _load_reference_histograms():
    refs = {}
    for safe_name, org in ORG_NAMES.items():
        path = os.path.join(LOGO_REF_DIR, f"{safe_name}.png")
        if not os.path.exists(path):
            continue
        img = cv2.imread(path)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [50, 60], [0, 180, 0, 256])
        cv2.normalize(hist, hist)
        refs[org] = hist
    return refs


_REFERENCE_HISTS = _load_reference_histograms()


def classify_certificate_logo(image_path):
    """Crop the fixed logo region and classify it against the 5 known issuer logos."""
    img = cv2.imread(image_path)
    if img is None or not _REFERENCE_HISTS:
        return {"detected_org": None, "confidence": 0.0, "all_scores": {}}

    x1, y1, x2, y2 = LOGO_BBOX
    h, w = img.shape[:2]
    x1, y1, x2, y2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
    crop = img[y1:y2, x1:x2]
    if crop.size == 0:
        return {"detected_org": None, "confidence": 0.0, "all_scores": {}}

    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [50, 60], [0, 180, 0, 256])
    cv2.normalize(hist, hist)

    scores = {
        org: max(0.0, float(cv2.compareHist(hist, ref, cv2.HISTCMP_CORREL)))
        for org, ref in _REFERENCE_HISTS.items()
    }
    if not scores:
        return {"detected_org": None, "confidence": 0.0, "all_scores": {}}

    best_org = max(scores, key=scores.get)
    return {
        "detected_org": best_org,
        "confidence": round(scores[best_org] * 100, 1),
        "all_scores": {k: round(v * 100, 1) for k, v in scores.items()},
    }


def detect_logo(image_path):
    """Generic 'is there probably a logo in the header' heuristic, used for resumes."""

    image = cv2.imread(image_path)

    if image is None:
        return {
            "detected": False,
            "message": "Could not open image"
        }

    height, width = image.shape[:2]

    top_region = image[0:int(height * 0.30), 0:width]

    gray = cv2.cvtColor(top_region, cv2.COLOR_BGR2GRAY)

    edges = cv2.Canny(gray, 100, 200)

    edge_pixels = cv2.countNonZero(edges)
    total_pixels = edges.shape[0] * edges.shape[1]

    if total_pixels == 0:
        return {
            "detected": False,
            "message": "No logo region detected"
        }

    edge_density = edge_pixels / total_pixels

    if edge_density > 0.03:
        return {
            "detected": True,
            "message": "Possible logo detected in resume header",
            "score": round(edge_density * 100, 2)
        }

    return {
        "detected": False,
        "message": "No obvious logo detected",
        "score": round(edge_density * 100, 2)
    }
