import re
from datetime import datetime
from rapidfuzz import fuzz


# The issuer database stores dates as "29-Dec-24" while the certificate
# image prints them as "19 Feb 2025" - both formats are tried so a date
# that is genuinely the same isn't flagged just because of formatting.
_DATE_FORMATS = ("%d-%b-%y", "%d-%b-%Y", "%d %b %Y", "%d %B %Y", "%d/%m/%Y")


def _parse_date(value):
    value = str(value).strip()
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def _extract_line_value(text, label_pattern):
    """Pull the value that follows a 'LABEL: value' line in the OCR text."""
    m = re.search(label_pattern + r"\s*[:\-]?\s*([^\n\r]+)", text, re.IGNORECASE)
    return m.group(1).strip() if m else ""


def compare_certificate(ocr_text, database_record):

    text = ocr_text.lower()

    expected_name = str(database_record["candidate_name"]).lower()
    expected_course = str(database_record["course_name"]).lower()
    expected_organization = str(
        database_record["issuing_organization"]
    ).lower()

    name_score = fuzz.partial_ratio(expected_name, text)

    course_score = fuzz.partial_ratio(expected_course, text)

    organization_score = fuzz.partial_ratio(
        expected_organization,
        text
    )

    name_match = name_score >= 80
    course_match = course_score >= 80
    organization_match = organization_score >= 80

    # --------------------------------------------------------------
    # Certificate ID (as printed on the document body, independent of
    # whatever ID the QR code encodes - catches a scrambled/edited
    # printed ID even if the QR still points at the real certificate).
    # --------------------------------------------------------------
    printed_id = _extract_line_value(ocr_text, r"CERTIFICATE\s*ID")
    printed_id_clean = re.sub(r"[^A-Za-z0-9\-]", "", printed_id)
    expected_id = str(database_record["certificate_id"]).strip()
    id_score = fuzz.ratio(printed_id_clean.upper(), expected_id.upper())
    id_match = id_score >= 70  # short strings: a real edit drops far below this (see module README)

    # --------------------------------------------------------------
    # Issue Date / Expiry Date - compared as parsed dates, not raw
    # strings, since the issuer database and the printed certificate
    # use different date formats.
    # --------------------------------------------------------------
    def _date_check(label_pattern, db_column):
        printed_raw = _extract_line_value(ocr_text, label_pattern)
        printed_dt = _parse_date(printed_raw)
        expected_dt = _parse_date(database_record[db_column])
        if printed_dt is None or expected_dt is None:
            # Couldn't confidently parse one side - don't silently pass.
            return False, printed_raw
        return printed_dt.date() == expected_dt.date(), printed_raw

    issue_date_match, printed_issue_date = _date_check(r"ISSUE\s*DATE", "issue_date")
    expiry_date_match, printed_expiry_date = _date_check(r"EXPIRY\s*DATE", "expiry_date")

    return {
        "name_score": name_score,
        "course_score": course_score,
        "organization_score": organization_score,
        "name_match": name_match,
        "course_match": course_match,
        "organization_match": organization_match,
        "id_score": id_score,
        "id_match": id_match,
        "printed_certificate_id": printed_id_clean,
        "issue_date_match": issue_date_match,
        "printed_issue_date": printed_issue_date,
        "expiry_date_match": expiry_date_match,
        "printed_expiry_date": printed_expiry_date,
        "expected_organization": str(database_record["issuing_organization"]),
        "expected_name": str(database_record["candidate_name"]),
        "expected_course": str(database_record["course_name"]),
        "expected_issue_date": str(database_record["issue_date"]),
        "expected_expiry_date": str(database_record["expiry_date"]),
    }
