import os
from modules.qr_verifier import verify_qr
from modules.issuer_verifier import load_issuer_database


image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")


# Step 1: Read QR
qr_result = verify_qr(image_path)

print("==============================")
print("     CERTIFICATE VERIFICATION")
print("==============================")

print("QR Found       :", qr_result["qr_found"])
print("QR Data        :", qr_result["data"])
print("Certificate ID :", qr_result["certificate_id"])

if not qr_result["qr_found"]:
    print("Result         : ❌ QR NOT FOUND")
    exit()


# Step 2: Get certificate ID
certificate_id = qr_result["certificate_id"]


# Step 3: Load issuer database
data = load_issuer_database()


# Step 4: Search certificate ID
match = data[
    data["certificate_id"].astype(str).str.strip() == certificate_id
]


if not match.empty:

    row = match.iloc[0]

    print()
    print("Certificate Details")
    print("------------------------------")
    print("Candidate Name :", row["candidate_name"])
    print("Course         :", row["course_name"])
    print("Issue Date     :", row["issue_date"])
    print("Expiry Date    :", row["expiry_date"])
    print("Organization   :", row["issuing_organization"])

    print()
    print("RESULT         : ✅ CERTIFICATE VERIFIED")

else:

    print()
    print("RESULT         : ❌ CERTIFICATE NOT FOUND")


print("==============================")
