import streamlit as st
import pandas as pd
import glob
import os

from theme.style import inject_base_css, hero, sidebar_brand, stat_card, MUTED

st.set_page_config(
    page_title="CertiShield AI — Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_base_css()
sidebar_brand()

with st.sidebar:
    st.markdown("**Navigate**")
    st.page_link("Home.py", label="Dashboard", icon="🏠")
    st.page_link("pages/1_Certificate_Verification.py", label="Certificate Verification", icon="🔍")
    st.page_link("pages/2_Resume_Analysis.py", label="Resume Analysis", icon="📄")
    st.page_link("pages/3_Batch_Analytics.py", label="Batch Analytics", icon="📊")
    st.markdown("---")
    st.caption("CertiShield AI · v1.0")
    st.caption("AI Resume & Certificate Authenticity Verification System")

hero(
    "CertiShield AI",
    "An AI-assisted pipeline that reads, cross-checks, and authenticates academic "
    "certificates and resumes — combining OCR, QR verification, issuer-database "
    "cross-matching, and logo classification into one clear verdict.",
)

# ---- Top stat row (dataset-level, computed live from the bundled sample dataset) ----
DATA_DIR = os.path.join(os.path.dirname(__file__), "dataset")
meta_path = os.path.join(DATA_DIR, "metadata.csv")

col1, col2, col3, col4 = st.columns(4)

if os.path.exists(meta_path):
    meta = pd.read_csv(meta_path)
    total = len(meta)
    genuine = int((meta["is_tampered"] == 0).sum())
    tampered = int((meta["is_tampered"] == 1).sum())
    issuers = meta["issuing_organization"].nunique()
else:
    total = genuine = tampered = issuers = 0

stat_card("Sample Certificates", total, "bundled demo dataset", col1)
stat_card("Genuine Records", genuine, "in issuer database", col2)
stat_card("Tampered Samples", tampered, "for testing detection", col3)
stat_card("Known Issuers", issuers, "logo-verified organizations", col4)

st.write("")

# ---- Feature cards / quick actions ----
c1, c2, c3 = st.columns(3)

with c1:
    st.markdown(
        """
        <div class="cs-card">
            <h3>🔍 Certificate Verification</h3>
            <p style="color:%s;">Upload a certificate image. The system decodes its QR code,
            reads every printed field, classifies the issuer logo, and cross-checks all of it
            against the official issuer database — returning a precise, per-field verdict.</p>
        </div>
        """ % MUTED,
        unsafe_allow_html=True,
    )
    st.page_link("pages/1_Certificate_Verification.py", label="Open Certificate Verification →", icon="🔍")

with c2:
    st.markdown(
        """
        <div class="cs-card">
            <h3>📄 Resume Analysis</h3>
            <p style="color:%s;">Upload a resume (PDF, PNG, or JPG). Extracts candidate name,
            contact details, education, skills, and any referenced certificate IDs — ready
            for a follow-up certificate check.</p>
        </div>
        """ % MUTED,
        unsafe_allow_html=True,
    )
    st.page_link("pages/2_Resume_Analysis.py", label="Open Resume Analysis →", icon="📄")

with c3:
    st.markdown(
        """
        <div class="cs-card">
            <h3>📊 Batch Analytics</h3>
            <p style="color:%s;">Run the full verification pipeline across the entire sample
            dataset in one click and see measured accuracy, precision, recall, and a
            confusion matrix — not just a single result.</p>
        </div>
        """ % MUTED,
        unsafe_allow_html=True,
    )
    st.page_link("pages/3_Batch_Analytics.py", label="Open Batch Analytics →", icon="📊")

st.write("")

# ---- How it works ----
st.markdown("### How a certificate is verified")

steps = [
    ("1", "QR Decode", "OpenCV reads the embedded QR code to resolve the claimed Certificate ID."),
    ("2", "OCR Extraction", "Tesseract OCR reads every printed field — name, course, org, dates, ID."),
    ("3", "Logo Classification", "The issuer logo is classified against 5 known reference logos."),
    ("4", "Issuer Cross-Check", "Every field is fuzzy-matched against the official issuer database."),
    ("5", "Final Verdict", "All checks are fused into one verdict with a transparent reason list."),
]

cols = st.columns(5)
for col, (num, title, desc) in zip(cols, steps):
    with col:
        st.markdown(
            f"""
            <div class="cs-card" style="min-height:170px;">
                <div style="width:34px;height:34px;border-radius:50%;background:#141A47;
                            color:white;display:flex;align-items:center;justify-content:center;
                            font-weight:700;margin-bottom:10px;">{num}</div>
                <b>{title}</b>
                <p style="color:{MUTED};font-size:0.85rem;margin-top:6px;">{desc}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )

st.write("")
st.caption(
    "Built on classical OCR + fuzzy string matching + colour-based logo classification. "
    "See the Batch Analytics page for measured accuracy on the bundled dataset."
)
