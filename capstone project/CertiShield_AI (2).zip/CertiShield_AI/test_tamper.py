import os
from modules.tamper_detector import detect_tampering


image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")


result = detect_tampering(image_path)


print("==============================")
print("       TAMPER DETECTION")
print("==============================")

print("Tampered :", result["tampered"])
print("Score    :", result["score"])
print("Message  :", result["message"])

print("==============================")