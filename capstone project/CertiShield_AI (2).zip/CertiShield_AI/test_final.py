"""
End-to-end CLI test using the same service layer the Streamlit app calls
(services/certificate_service.py), so this always reflects exactly what
the website does - QR decode, OCR, logo classification, and issuer
cross-check (name, course, organization, both dates, and the printed ID).
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from services.certificate_service import verify_certificate

image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")

result = verify_certificate(image_path)
final = result["final"]

print()
print("========================================")
print("     CERTIFICATE AUTHENTICITY REPORT")
print("========================================")
print()
print("Certificate ID        :", result["qr_result"].get("certificate_id"))
print()
print("----------------------------------------")
print("VERIFICATION RESULTS")
print("----------------------------------------")
print("QR Verification        :", final["qr_status"])
print("Certificate ID Match    :", final["id_status"])
print("Name Verification       :", final["name_status"])
print("Course Verification     :", final["course_status"])
print("Issuer Verification     :", final["issuer_status"])
print("Issue Date Verification :", final["issue_date_status"])
print("Expiry Date Verification:", final["expiry_date_status"])
print("Logo Match               :", final["logo_status"])
print("Visual Integrity (info) :", final["tamper_status"], f"(score {final['visual_score']})")
print()
print("----------------------------------------")
print(f"FINAL RESULT            : {final['final_result']}  ({final['confidence']}% confidence)")
print("----------------------------------------")

if final["reasons"]:
    print()
    print("REASONS:")
    for reason in final["reasons"]:
        print("-", reason)
else:
    print()
    print("All verification checks passed.")

print("========================================")
