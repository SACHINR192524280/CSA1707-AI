from modules.issuer_verifier import verify_certificate


result = verify_certificate(
    "CERT-XAJI0Y6D",
    "Allison Hill",
    "Data Structures & Algorithms"
)

print("================================")
print("   CERTIFICATE VERIFICATION")
print("================================")

print("Certificate ID :", result["certificate_id"])
print("Name Match     :", result["name_score"], "%")
print("Course Match   :", result["course_score"], "%")

print("--------------------------------")

if result["verified"]:
    print("RESULT: VERIFIED")
else:
    print("RESULT: NOT VERIFIED")

print("Message:", result["message"])
print("================================")