import os
from modules.ocr_engine import extract_text


image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")


result = extract_text(image_path)


print("==============================")
print("          OCR TEST")
print("==============================")

print("Success :", result["success"])
print("Message :", result["message"])

print()
print("EXTRACTED TEXT")
print("------------------------------")
print(result["text"])

print("==============================")