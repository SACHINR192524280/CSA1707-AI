from modules.resume_parser import parse_resume
from modules.resume_certificate_matcher import match_resume_certificate


# Sample resume
resume_text = """
Rithish Kumar

rithish@example.com
9876543210

B.E Cyber Security

Python
Java
Linux

CERT-XCXAPRPN
"""


# Parse resume
parsed_resume = parse_resume(resume_text)


# Simulated issuer database record
database_record = {
    "candidate_name": "Rithish Kumar",
    "certificate_id": "CERT-XCXAPRPN"
}


# Match
result = match_resume_certificate(
    parsed_resume,
    database_record
)


print("==============================")
print(" RESUME-CERTIFICATE MATCHER")
print("==============================")

print("Resume Name      :", result["resume_name"])
print("Database Name    :", result["database_name"])

print("Certificate ID   :", result["certificate_id"])

print()
print("Certificate Match:",
      result["certificate_match"])

print("Name Match       :",
      result["name_match"])

print("Name Score       :",
      result["name_score"])

print()
print("FINAL RESULT     :",
      result["final_result"])

print("==============================")