import os
from modules.ocr_engine import extract_text
from modules.qr_verifier import verify_qr
from modules.issuer_verifier import load_issuer_database
from modules.cross_verifier import compare_certificate


image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")


# -----------------------------
# 1. QR VERIFICATION
# -----------------------------

qr = verify_qr(image_path)

certificate_id = qr["certificate_id"]


# -----------------------------
# 2. DATABASE LOOKUP
# -----------------------------

data = load_issuer_database()

match = data[
    data["certificate_id"].astype(str).str.strip()
    == certificate_id
]


if match.empty:

    print("Certificate not found in issuer database")

    exit()


record = match.iloc[0]


# -----------------------------
# 3. OCR
# -----------------------------

ocr = extract_text(image_path)

ocr_text = ocr["text"]


# -----------------------------
# 4. CROSS VERIFICATION
# -----------------------------

result = compare_certificate(
    ocr_text,
    record
)


# -----------------------------
# 5. DISPLAY
# -----------------------------

print("==============================")
print("   CROSS VERIFICATION")
print("==============================")

print("Certificate ID :", certificate_id)

print()
print("Database Name  :", record["candidate_name"])
print("Database Course:", record["course_name"])
print("Database Issuer:", record["issuing_organization"])

print()
print("Name Score     :", result["name_score"])
print("Course Score   :", result["course_score"])
print("Issuer Score   :", result["organization_score"])

print()
print("Name Match     :", result["name_match"])
print("Course Match   :", result["course_match"])
print("Issuer Match   :", result["organization_match"])

print("==============================")