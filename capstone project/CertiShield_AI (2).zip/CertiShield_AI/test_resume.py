from modules.resume_parser import parse_resume


text = """
Rithish Kumar

rithish@example.com
9876543210

B.E Cyber Security

Skills:
Python
Java
Linux
Machine Learning

CERT-ABC123
"""


result = parse_resume(text)


print("==============================")
print("       RESUME PARSER")
print("==============================")

print("Name        :", result["name"])
print("Email       :", result["email"])
print("Phone       :", result["phone"])
print("Education   :", result["education"])
print("Skills      :", result["skills"])
print("Certificates:", result["certificates"])

print("==============================")
