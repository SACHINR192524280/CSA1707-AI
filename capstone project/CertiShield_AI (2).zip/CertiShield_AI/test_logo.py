import os
from modules.logo_detector import detect_logo


image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dataset", "images", "CERT-XCXAPRPN.png")

result = detect_logo(image_path)


print("==============================")
print("       LOGO DETECTOR")
print("==============================")

print("Detected :", result["detected"])
print("Message  :", result["message"])
print("Score    :", result.get("score", 0))

print("==============================")