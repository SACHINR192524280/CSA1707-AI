"""
Shared visual theme for CertiShield AI - injected on every page so the
whole app (Home + all pages/) looks like one consistent product instead
of a default Streamlit page.
"""

import streamlit as st

NAVY = "#141A47"
NAVY_DEEP = "#0B0E2E"
ACCENT = "#3D8BFD"
TEAL = "#0F8B8D"
GREEN = "#0E9F6E"
RED = "#E63946"
AMBER = "#F5A524"
INK = "#1B2140"
MUTED = "#6B7590"
CARD_BG = "#FFFFFF"
PAGE_BG = "#F4F6FB"


def inject_base_css():
    st.markdown(
        f"""
        <style>
        .stApp {{
            background: {PAGE_BG};
        }}

        /* Hide default Streamlit chrome for a cleaner "product" feel */
        #MainMenu {{visibility: hidden;}}
        footer {{visibility: hidden;}}
        .stAppDeployButton {{display: none;}}
        div[data-testid="stToolbarActions"] {{display: none;}}
        /* Hide Streamlit's auto-generated page list - we render our own nav below it */
        [data-testid="stSidebarNav"] {{display: none !important;}}
        [data-testid="stSidebarNavItems"] {{display: none !important;}}

        section[data-testid="stSidebar"] {{
            background: linear-gradient(180deg, {NAVY_DEEP} 0%, {NAVY} 100%);
        }}
        section[data-testid="stSidebar"] * {{
            color: #E8ECFB !important;
        }}
        section[data-testid="stSidebar"] hr {{
            border-color: rgba(255,255,255,0.15);
        }}

        h1, h2, h3, h4 {{
            color: {INK};
            font-family: "Georgia", "Cambria", serif;
        }}
        p, span, label, div {{
            font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
        }}

        /* Card container helper */
        .cs-card {{
            background: {CARD_BG};
            border: 1px solid #E4E9F5;
            border-radius: 14px;
            padding: 1.3rem 1.5rem;
            box-shadow: 0 2px 10px rgba(20, 26, 71, 0.05);
            margin-bottom: 1rem;
        }}

        .cs-badge {{
            display: inline-block;
            padding: 0.28rem 0.9rem;
            border-radius: 999px;
            font-weight: 700;
            font-size: 0.82rem;
            letter-spacing: 0.03em;
        }}
        .cs-badge-green {{ background: #E7F9F1; color: {GREEN}; }}
        .cs-badge-red {{ background: #FDECEE; color: {RED}; }}
        .cs-badge-amber {{ background: #FFF6E5; color: #A66A00; }}
        .cs-badge-gray {{ background: #EEF1F8; color: {MUTED}; }}

        .cs-hero {{
            background: linear-gradient(120deg, {NAVY_DEEP} 0%, {NAVY} 55%, #23306E 100%);
            border-radius: 18px;
            padding: 2.2rem 2.4rem;
            color: white;
            margin-bottom: 1.4rem;
        }}
        .cs-hero h1 {{
            color: white;
            margin-bottom: 0.3rem;
            font-size: 2.1rem;
        }}
        .cs-hero p {{
            color: #C7D0F0;
            font-size: 1.02rem;
            max-width: 780px;
        }}

        .cs-stat-num {{
            font-size: 2.1rem;
            font-weight: 800;
            color: {INK};
            line-height: 1.1;
        }}
        .cs-stat-label {{
            color: {MUTED};
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }}

        div[data-testid="stMetricValue"] {{
            color: {INK};
        }}

        .stButton>button, .stDownloadButton>button {{
            background: {NAVY};
            color: white;
            border-radius: 9px;
            border: none;
            font-weight: 600;
            padding: 0.55rem 1.4rem;
        }}
        .stButton>button:hover, .stDownloadButton>button:hover {{
            background: {ACCENT};
            color: white;
        }}

        div[data-testid="stFileUploaderDropzone"] {{
            border-radius: 12px;
            border: 1.5px dashed #B9C4E3;
            background: #FBFCFF;
        }}

        .cs-check-row {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.55rem 0;
            border-bottom: 1px solid #EEF1F8;
        }}
        .cs-check-row:last-child {{ border-bottom: none; }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def hero(title, subtitle, emoji="🛡️"):
    st.markdown(
        f"""
        <div class="cs-hero">
            <h1>{emoji} {title}</h1>
            <p>{subtitle}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def badge(text, kind="gray"):
    return f'<span class="cs-badge cs-badge-{kind}">{text}</span>'


def stat_card(label, value, sub=None, col=None):
    target = col if col is not None else st
    with target:
        sub_html = f'<div style="color:{MUTED};font-size:0.8rem;margin-top:2px;">{sub}</div>' if sub else ""
        st.markdown(
            f"""
            <div class="cs-card" style="text-align:center;">
                <div class="cs-stat-num">{value}</div>
                <div class="cs-stat-label">{label}</div>
                {sub_html}
            </div>
            """,
            unsafe_allow_html=True,
        )


def sidebar_brand():
    with st.sidebar:
        st.markdown(
            """
            <div style="padding: 0.6rem 0 1.2rem 0;">
                <div style="font-size:1.6rem; font-weight:800; color:white;">🛡️ CertiShield <span style="color:#3D8BFD;">AI</span></div>
                <div style="color:#9FA8CE; font-size:0.82rem; margin-top:2px;">Certificate & Resume Authenticity Platform</div>
            </div>
            <hr/>
            """,
            unsafe_allow_html=True,
        )
